# UniCollab — Student Collaboration Platform

A full-stack university-only platform where students can:
- Create and discover projects
- Request to join and collaborate
- Chat privately with project members
- Post problems and ideas to the community feed
- Like and comment on posts and projects

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite |
| Backend | Flask (Python) |
| Database | SQLite (via SQLAlchemy) |
| Auth | JWT (flask-jwt-extended) |
| Styling | Custom CSS (no framework) |

---

## Project Structure

```
student-collab-platform/
├── backend/
│   ├── app.py                  # Flask app factory
│   ├── requirements.txt
│   ├── .env.example
│   ├── models/
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── project.py
│   │   ├── collaboration.py
│   │   ├── message.py
│   │   └── post.py             # Post, Comment, Like
│   ├── routes/
│   │   ├── auth.py             # POST /register, POST /login
│   │   ├── users.py            # GET /profile
│   │   ├── projects.py         # CRUD + join/accept
│   │   ├── messages.py         # Project chat
│   │   └── feed.py             # Posts, likes, comments
│   └── services/
│       └── auth_service.py     # Password hashing, validation
└── frontend/
    ├── index.html
    ├── vite.config.js
    ├── package.json
    └── src/
        ├── main.jsx
        ├── App.jsx
        ├── index.css
        ├── context/
        │   └── AuthContext.jsx
        ├── services/
        │   └── api.js
        ├── components/
        │   ├── Layout.jsx
        │   └── Layout.css
        └── pages/
            ├── Login.jsx / Auth.css
            ├── Register.jsx
            ├── Dashboard.jsx / Dashboard.css
            ├── CreateProject.jsx / CreateProject.css
            ├── ProjectDetail.jsx / ProjectDetail.css
            ├── Chat.jsx / Chat.css
            └── Feed.jsx / Feed.css
```

---

## Local Setup

### 1. Clone or extract the project

```bash
cd student-collab-platform
```

### 2. Backend Setup

```bash
cd backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Create your .env file
cp .env.example .env
# Edit .env — set your ALLOWED_DOMAIN (e.g. university.edu)

# Run the server
python app.py
```

Backend runs on: **http://localhost:5000**

### 3. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Run dev server
npm run dev
```

Frontend runs on: **http://localhost:5173**

> The Vite proxy forwards all `/api/*` requests to Flask automatically.

---

## Environment Variables

Copy `backend/.env.example` to `backend/.env` and fill in:

```env
JWT_SECRET_KEY=your-very-long-random-secret-key
DATABASE_URL=sqlite:///collab.db
ALLOWED_DOMAIN=university.edu
```

Change `ALLOWED_DOMAIN` to your university's email domain.

---

## API Endpoints

### Auth
| Method | Path | Description |
|--------|------|-------------|
| POST | /api/register | Register new user |
| POST | /api/login | Login, get JWT token |

### Users
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | /api/profile | ✓ | Get current user profile |

### Projects
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | /api/projects | ✓ | Create project |
| GET | /api/projects | ✓ | List all projects |
| GET | /api/projects/:id | ✓ | Get project details |
| POST | /api/projects/:id/join | ✓ | Request to join |
| POST | /api/projects/:id/accept | ✓ | Accept/reject request |
| POST | /api/projects/:id/like | ✓ | Toggle like |
| GET | /api/projects/:id/comments | ✓ | Get comments |
| POST | /api/projects/:id/comments | ✓ | Post a comment |

### Messages (Project Chat)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | /api/projects/:id/messages | ✓ | Get chat messages |
| POST | /api/projects/:id/messages | ✓ | Send a message |

### Community Feed
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | /api/feed | ✓ | Get all posts |
| POST | /api/feed | ✓ | Create a post |
| GET | /api/feed/:id | ✓ | Get post + comments |
| DELETE | /api/feed/:id | ✓ | Delete own post |
| POST | /api/feed/:id/like | ✓ | Toggle like on post |
| POST | /api/feed/:id/comments | ✓ | Comment on post |
| DELETE | /api/comments/:id | ✓ | Delete own comment |

---

## Features

- **University-only signup** — restricted to configured email domain
- **JWT auth** — stored in localStorage, sent as Bearer token
- **Project chat** — only accessible to owner + accepted collaborators, polls every 4s
- **Community feed** — all users can post, like, and comment
- **Likes** — toggleable on both posts and projects
- **Join workflow** — request → owner accepts/rejects
- **GitHub validation** — must be a valid `github.com/user/repo` URL

---

## Deployment (Basic)

### Backend (e.g. Render, Railway, Fly.io)
1. Set environment variables in the platform dashboard
2. Change `DATABASE_URL` to a PostgreSQL URL for production
3. Set `debug=False` in `app.py`
4. Start command: `python app.py`

### Frontend (e.g. Vercel, Netlify)
1. `cd frontend && npm run build`
2. Deploy the `dist/` folder
3. Set the API base URL if backend is on a different domain (update `api.js`)

---

## Notes

- The SQLite database file (`collab.db`) is created automatically on first run
- Chat uses polling (every 4s) — upgrade to WebSockets for production
- Passwords are hashed with bcrypt
- JWT tokens expire after the default flask-jwt-extended duration (can be configured)
