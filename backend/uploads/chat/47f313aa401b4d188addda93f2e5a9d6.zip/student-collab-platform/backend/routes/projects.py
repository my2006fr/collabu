from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from models.project import Project
from models.collaboration import Collaboration
from models.user import User
from services.auth_service import is_valid_github_url

projects_bp = Blueprint("projects", __name__)


@projects_bp.route("/projects", methods=["POST"])
@jwt_required()
def create_project():
    user_id = int(get_jwt_identity())
    data = request.get_json()

    title = data.get("title", "").strip()
    description = data.get("description", "").strip()
    required_skills = data.get("required_skills", "")
    github_repo_link = data.get("github_repo_link", "").strip()
    methodology = data.get("methodology", "Agile")

    if not title or not description or not github_repo_link:
        return jsonify({"error": "Title, description, and GitHub repo link are required."}), 400

    if not is_valid_github_url(github_repo_link):
        return jsonify({"error": "Invalid GitHub repository URL."}), 400

    project = Project(
        title=title,
        description=description,
        required_skills=required_skills,
        github_repo_link=github_repo_link,
        methodology=methodology,
        owner_id=user_id,
    )
    db.session.add(project)
    db.session.commit()

    return jsonify(project.to_dict(current_user_id=user_id)), 201


@projects_bp.route("/projects", methods=["GET"])
@jwt_required()
def list_projects():
    user_id = int(get_jwt_identity())
    projects = Project.query.order_by(Project.created_at.desc()).all()
    return jsonify([p.to_dict(current_user_id=user_id) for p in projects]), 200


@projects_bp.route("/projects/<int:project_id>", methods=["GET"])
@jwt_required()
def get_project(project_id):
    user_id = int(get_jwt_identity())
    project = Project.query.get(project_id)
    if not project:
        return jsonify({"error": "Project not found."}), 404

    data = project.to_dict(current_user_id=user_id)
    data["collaborators"] = [c.to_dict() for c in project.collaborations if c.status == "accepted"]
    data["pending_requests"] = [c.to_dict() for c in project.collaborations if c.status == "pending"]
    return jsonify(data), 200


@projects_bp.route("/projects/<int:project_id>/join", methods=["POST"])
@jwt_required()
def join_project(project_id):
    user_id = int(get_jwt_identity())

    project = Project.query.get(project_id)
    if not project:
        return jsonify({"error": "Project not found."}), 404

    if project.owner_id == user_id:
        return jsonify({"error": "You are the owner of this project."}), 400

    existing = Collaboration.query.filter_by(user_id=user_id, project_id=project_id).first()
    if existing:
        return jsonify({"error": f"Request already exists with status: {existing.status}."}), 409

    collab = Collaboration(user_id=user_id, project_id=project_id, status="pending")
    db.session.add(collab)
    db.session.commit()

    return jsonify(collab.to_dict()), 201


@projects_bp.route("/projects/<int:project_id>/accept", methods=["POST"])
@jwt_required()
def accept_or_reject(project_id):
    owner_id = int(get_jwt_identity())

    project = Project.query.get(project_id)
    if not project:
        return jsonify({"error": "Project not found."}), 404

    if project.owner_id != owner_id:
        return jsonify({"error": "Only the project owner can manage requests."}), 403

    data = request.get_json()
    user_id = data.get("user_id")
    action = data.get("action")

    if not user_id or action not in ("accept", "reject"):
        return jsonify({"error": "user_id and action (accept/reject) are required."}), 400

    collab = Collaboration.query.filter_by(user_id=user_id, project_id=project_id).first()
    if not collab:
        return jsonify({"error": "Collaboration request not found."}), 404

    collab.status = "accepted" if action == "accept" else "rejected"
    db.session.commit()

    return jsonify(collab.to_dict()), 200
