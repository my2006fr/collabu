from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from models.post import Post, Comment, Like
from models.project import Project

feed_bp = Blueprint("feed", __name__)


# ─── POSTS ────────────────────────────────────────────────────────────────────

@feed_bp.route("/feed", methods=["GET"])
@jwt_required()
def get_feed():
    user_id = int(get_jwt_identity())
    posts = Post.query.order_by(Post.created_at.desc()).all()
    return jsonify([p.to_dict(current_user_id=user_id) for p in posts]), 200


@feed_bp.route("/feed", methods=["POST"])
@jwt_required()
def create_post():
    user_id = int(get_jwt_identity())
    data = request.get_json()

    title = data.get("title", "").strip()
    content = data.get("content", "").strip()

    if not title or not content:
        return jsonify({"error": "Title and content are required."}), 400

    post = Post(author_id=user_id, title=title, content=content)
    db.session.add(post)
    db.session.commit()

    return jsonify(post.to_dict(current_user_id=user_id)), 201


@feed_bp.route("/feed/<int:post_id>", methods=["GET"])
@jwt_required()
def get_post(post_id):
    user_id = int(get_jwt_identity())
    post = Post.query.get(post_id)
    if not post:
        return jsonify({"error": "Post not found."}), 404

    data = post.to_dict(current_user_id=user_id)
    data["comments"] = [c.to_dict() for c in post.comments]
    return jsonify(data), 200


@feed_bp.route("/feed/<int:post_id>", methods=["DELETE"])
@jwt_required()
def delete_post(post_id):
    user_id = int(get_jwt_identity())
    post = Post.query.get(post_id)
    if not post:
        return jsonify({"error": "Post not found."}), 404
    if post.author_id != user_id:
        return jsonify({"error": "You can only delete your own posts."}), 403

    db.session.delete(post)
    db.session.commit()
    return jsonify({"message": "Post deleted."}), 200


# ─── LIKES ────────────────────────────────────────────────────────────────────

@feed_bp.route("/feed/<int:post_id>/like", methods=["POST"])
@jwt_required()
def toggle_post_like(post_id):
    user_id = int(get_jwt_identity())
    post = Post.query.get(post_id)
    if not post:
        return jsonify({"error": "Post not found."}), 404

    existing = Like.query.filter_by(user_id=user_id, post_id=post_id).first()
    if existing:
        db.session.delete(existing)
        db.session.commit()
        return jsonify({"liked": False, "likes_count": len(post.likes)}), 200

    like = Like(user_id=user_id, post_id=post_id)
    db.session.add(like)
    db.session.commit()
    return jsonify({"liked": True, "likes_count": len(post.likes)}), 201


@feed_bp.route("/projects/<int:project_id>/like", methods=["POST"])
@jwt_required()
def toggle_project_like(project_id):
    user_id = int(get_jwt_identity())
    project = Project.query.get(project_id)
    if not project:
        return jsonify({"error": "Project not found."}), 404

    existing = Like.query.filter_by(user_id=user_id, project_id=project_id).first()
    if existing:
        db.session.delete(existing)
        db.session.commit()
        liked_count = Like.query.filter_by(project_id=project_id).count()
        return jsonify({"liked": False, "likes_count": liked_count}), 200

    like = Like(user_id=user_id, project_id=project_id)
    db.session.add(like)
    db.session.commit()
    liked_count = Like.query.filter_by(project_id=project_id).count()
    return jsonify({"liked": True, "likes_count": liked_count}), 201


# ─── COMMENTS ─────────────────────────────────────────────────────────────────

@feed_bp.route("/feed/<int:post_id>/comments", methods=["POST"])
@jwt_required()
def comment_on_post(post_id):
    user_id = int(get_jwt_identity())
    post = Post.query.get(post_id)
    if not post:
        return jsonify({"error": "Post not found."}), 404

    data = request.get_json()
    content = data.get("content", "").strip()
    if not content:
        return jsonify({"error": "Comment cannot be empty."}), 400

    comment = Comment(author_id=user_id, post_id=post_id, content=content)
    db.session.add(comment)
    db.session.commit()
    return jsonify(comment.to_dict()), 201


@feed_bp.route("/projects/<int:project_id>/comments", methods=["GET"])
@jwt_required()
def get_project_comments(project_id):
    project = Project.query.get(project_id)
    if not project:
        return jsonify({"error": "Project not found."}), 404

    comments = (
        Comment.query.filter_by(project_id=project_id)
        .order_by(Comment.created_at.asc())
        .all()
    )
    return jsonify([c.to_dict() for c in comments]), 200


@feed_bp.route("/projects/<int:project_id>/comments", methods=["POST"])
@jwt_required()
def comment_on_project(project_id):
    user_id = int(get_jwt_identity())
    project = Project.query.get(project_id)
    if not project:
        return jsonify({"error": "Project not found."}), 404

    data = request.get_json()
    content = data.get("content", "").strip()
    if not content:
        return jsonify({"error": "Comment cannot be empty."}), 400

    comment = Comment(author_id=user_id, project_id=project_id, content=content)
    db.session.add(comment)
    db.session.commit()
    return jsonify(comment.to_dict()), 201


@feed_bp.route("/comments/<int:comment_id>", methods=["DELETE"])
@jwt_required()
def delete_comment(comment_id):
    user_id = int(get_jwt_identity())
    comment = Comment.query.get(comment_id)
    if not comment:
        return jsonify({"error": "Comment not found."}), 404
    if comment.author_id != user_id:
        return jsonify({"error": "You can only delete your own comments."}), 403

    db.session.delete(comment)
    db.session.commit()
    return jsonify({"message": "Comment deleted."}), 200
