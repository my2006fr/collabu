from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from models.message import Message
from models.project import Project
from models.collaboration import Collaboration

messages_bp = Blueprint("messages", __name__)


def _is_member(user_id, project):
    """Check if user is owner or accepted collaborator."""
    if project.owner_id == user_id:
        return True
    collab = Collaboration.query.filter_by(
        user_id=user_id, project_id=project.id, status="accepted"
    ).first()
    return collab is not None


@messages_bp.route("/projects/<int:project_id>/messages", methods=["GET"])
@jwt_required()
def get_messages(project_id):
    user_id = int(get_jwt_identity())
    project = Project.query.get(project_id)
    if not project:
        return jsonify({"error": "Project not found."}), 404

    if not _is_member(user_id, project):
        return jsonify({"error": "Access denied. You must be a member of this project."}), 403

    messages = (
        Message.query.filter_by(project_id=project_id)
        .order_by(Message.sent_at.asc())
        .all()
    )
    return jsonify([m.to_dict() for m in messages]), 200


@messages_bp.route("/projects/<int:project_id>/messages", methods=["POST"])
@jwt_required()
def send_message(project_id):
    user_id = int(get_jwt_identity())
    project = Project.query.get(project_id)
    if not project:
        return jsonify({"error": "Project not found."}), 404

    if not _is_member(user_id, project):
        return jsonify({"error": "Access denied. You must be a member of this project."}), 403

    data = request.get_json()
    content = data.get("content", "").strip()
    if not content:
        return jsonify({"error": "Message content cannot be empty."}), 400

    msg = Message(project_id=project_id, sender_id=user_id, content=content)
    db.session.add(msg)
    db.session.commit()

    return jsonify(msg.to_dict()), 201
