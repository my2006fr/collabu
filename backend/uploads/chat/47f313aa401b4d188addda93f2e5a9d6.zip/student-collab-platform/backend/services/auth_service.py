import bcrypt
import re


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def check_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))


def is_valid_email_domain(email: str, allowed_domain: str) -> bool:
    return email.strip().lower().endswith(f"@{allowed_domain}")


def is_valid_github_url(url: str) -> bool:
    pattern = r"^https?://(www\.)?github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"
    return bool(re.match(pattern, url))
