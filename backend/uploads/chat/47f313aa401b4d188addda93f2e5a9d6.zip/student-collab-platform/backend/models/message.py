from app import db
from datetime import datetime


class Message(db.Model):
    __tablename__ = "messages"

    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey("projects.id"), nullable=False)
    sender_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    content = db.Column(db.Text, nullable=False)
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)

    sender = db.relationship("User", backref="messages", lazy=True)
    project = db.relationship("Project", backref="messages", lazy=True)

    def to_dict(self):
        return {
            "id": self.id,
            "project_id": self.project_id,
            "sender_id": self.sender_id,
            "content": self.content,
            "sent_at": self.sent_at.isoformat(),
            "sender": {
                "id": self.sender.id,
                "name": self.sender.name,
            } if self.sender else None,
        }
