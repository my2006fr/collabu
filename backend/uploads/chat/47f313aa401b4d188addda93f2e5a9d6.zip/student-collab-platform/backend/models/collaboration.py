from app import db
from datetime import datetime


class Collaboration(db.Model):
    __tablename__ = "collaborations"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    project_id = db.Column(db.Integer, db.ForeignKey("projects.id"), nullable=False)
    status = db.Column(db.String(20), default="pending")  # pending / accepted / rejected
    requested_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "project_id": self.project_id,
            "status": self.status,
            "requested_at": self.requested_at.isoformat(),
            "user": (
                {"id": self.user.id, "name": self.user.name, "email": self.user.email}
                if self.user
                else None
            ),
        }
