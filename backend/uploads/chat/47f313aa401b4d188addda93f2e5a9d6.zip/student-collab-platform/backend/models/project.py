from app import db
from datetime import datetime


class Project(db.Model):
    __tablename__ = "projects"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    required_skills = db.Column(db.Text, default="")
    github_repo_link = db.Column(db.String(300), nullable=False)
    methodology = db.Column(db.String(50), default="Agile")
    owner_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    collaborations = db.relationship("Collaboration", backref="project", lazy=True)

    def to_dict(self, include_owner=True, current_user_id=None):
        from models.post import Like
        likes = Like.query.filter_by(project_id=self.id).all()
        data = {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "required_skills": self.required_skills,
            "github_repo_link": self.github_repo_link,
            "methodology": self.methodology,
            "owner_id": self.owner_id,
            "created_at": self.created_at.isoformat(),
            "likes_count": len(likes),
            "liked_by_me": any(l.user_id == current_user_id for l in likes) if current_user_id else False,
        }
        if include_owner and self.owner:
            data["owner"] = {
                "id": self.owner.id,
                "name": self.owner.name,
                "email": self.owner.email,
            }
        return data
