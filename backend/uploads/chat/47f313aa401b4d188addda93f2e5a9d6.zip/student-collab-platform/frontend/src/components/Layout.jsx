import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import './Layout.css'

export default function Layout() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => { logout(); navigate('/login') }

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <span className="brand-icon">⬡</span>
          <span className="brand-name">UniCollab</span>
        </div>

        <nav className="sidebar-nav">
          <NavLink to="/dashboard" className={({isActive})=> isActive ? 'nav-item active' : 'nav-item'}>
            <span className="nav-icon">◈</span> Projects
          </NavLink>
          <NavLink to="/feed" className={({isActive})=> isActive ? 'nav-item active' : 'nav-item'}>
            <span className="nav-icon">◉</span> Community Feed
          </NavLink>
          <NavLink to="/projects/new" className={({isActive})=> isActive ? 'nav-item active' : 'nav-item'}>
            <span className="nav-icon">✦</span> New Project
          </NavLink>
        </nav>

        <div className="sidebar-footer">
          <div className="user-info">
            <div className="user-avatar">{user?.name?.[0]?.toUpperCase()}</div>
            <div className="user-meta">
              <div className="user-name">{user?.name}</div>
              <div className="user-level">{user?.level}</div>
            </div>
          </div>
          <button className="btn-ghost btn-sm logout-btn" onClick={handleLogout}>Sign out</button>
        </div>
      </aside>

      <main className="main-content">
        <Outlet />
      </main>
    </div>
  )
}
