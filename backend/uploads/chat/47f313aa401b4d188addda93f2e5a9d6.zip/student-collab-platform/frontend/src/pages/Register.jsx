import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { api } from '../services/api'
import './Auth.css'

export default function Register() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '', skills: '', level: 'beginner' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const data = await api.register(form)
      login(data.token, data.user)
      navigate('/dashboard')
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card fade-up">
        <div className="auth-header">
          <span className="auth-logo">⬡</span>
          <h1>Join UniCollab</h1>
          <p>Create your university student account</p>
        </div>

        {error && <div className="error-msg">{error}</div>}

        <form onSubmit={submit} className="auth-form">
          <div className="field">
            <label>Full Name</label>
            <input name="name" placeholder="Ada Lovelace" value={form.name} onChange={handle} required />
          </div>
          <div className="field">
            <label>University Email</label>
            <input name="email" type="email" placeholder="you@university.edu" value={form.email} onChange={handle} required />
          </div>
          <div className="field">
            <label>Password</label>
            <input name="password" type="password" placeholder="••••••••" value={form.password} onChange={handle} required />
          </div>
          <div className="field">
            <label>Skills <span style={{color:'var(--text3)'}}>— e.g. React, Python, ML</span></label>
            <input name="skills" placeholder="React, Python, Machine Learning…" value={form.skills} onChange={handle} />
          </div>
          <div className="field">
            <label>Level</label>
            <select name="level" value={form.level} onChange={handle}>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>
          <button type="submit" className="btn-primary" style={{width:'100%'}} disabled={loading}>
            {loading ? 'Creating account…' : 'Create Account'}
          </button>
        </form>

        <p className="auth-switch">
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </div>
    </div>
  )
}
