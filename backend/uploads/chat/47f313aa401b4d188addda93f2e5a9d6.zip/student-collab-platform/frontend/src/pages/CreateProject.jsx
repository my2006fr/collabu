import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { api } from '../services/api'
import './CreateProject.css'

const METHODOLOGIES = ['Agile', 'Scrum', 'Kanban', 'Waterfall', 'XP', 'Lean']

export default function CreateProject() {
  const { token } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({
    title: '', description: '', required_skills: '',
    github_repo_link: '', methodology: 'Agile',
  })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const project = await api.createProject(form, token)
      navigate(`/projects/${project.id}`)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="create-page fade-up">
      <div className="create-header">
        <h1>New Project</h1>
        <p className="subtitle">Start something great with your peers</p>
      </div>

      <div className="create-card card">
        {error && <div className="error-msg" style={{marginBottom:16}}>{error}</div>}

        <form onSubmit={submit} className="create-form">
          <div className="field">
            <label>Project Title *</label>
            <input name="title" placeholder="AI-powered study planner" value={form.title} onChange={handle} required />
          </div>

          <div className="field">
            <label>Description *</label>
            <textarea name="description" rows={4} placeholder="Describe what you're building and what you need…" value={form.description} onChange={handle} required />
          </div>

          <div className="form-row">
            <div className="field">
              <label>Required Skills</label>
              <input name="required_skills" placeholder="Python, React, ML, etc." value={form.required_skills} onChange={handle} />
            </div>
            <div className="field">
              <label>Methodology</label>
              <select name="methodology" value={form.methodology} onChange={handle}>
                {METHODOLOGIES.map(m => <option key={m}>{m}</option>)}
              </select>
            </div>
          </div>

          <div className="field">
            <label>GitHub Repository URL *</label>
            <input
              name="github_repo_link"
              placeholder="https://github.com/username/repo"
              value={form.github_repo_link}
              onChange={handle}
              required
            />
            <span className="field-hint">Must be a valid GitHub URL</span>
          </div>

          <div className="form-actions">
            <button type="button" className="btn-secondary" onClick={() => navigate('/dashboard')}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? 'Creating…' : '✦ Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
