import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { api } from '../services/api'
import './Feed.css'

function PostCard({ post, token, currentUser, onUpdate, onDelete }) {
  const [expanded, setExpanded] = useState(false)
  const [comments, setComments] = useState([])
  const [commentText, setCommentText] = useState('')
  const [liked, setLiked] = useState(post.liked_by_me)
  const [likesCount, setLikesCount] = useState(post.likes_count)
  const [loadingComments, setLoadingComments] = useState(false)

  const toggleExpand = async () => {
    if (!expanded) {
      setLoadingComments(true)
      try {
        const data = await api.getPost(post.id, token)
        setComments(data.comments || [])
      } catch (e) {}
      setLoadingComments(false)
    }
    setExpanded(!expanded)
  }

  const handleLike = async () => {
    try {
      const res = await api.likePost(post.id, token)
      setLiked(res.liked)
      setLikesCount(res.likes_count)
    } catch (e) {}
  }

  const handleComment = async (e) => {
    e.preventDefault()
    if (!commentText.trim()) return
    try {
      const c = await api.commentOnPost(post.id, { content: commentText }, token)
      setComments([...comments, c])
      setCommentText('')
      onUpdate()
    } catch (e) {}
  }

  const handleDeleteComment = async (cid) => {
    try {
      await api.deleteComment(cid, token)
      setComments(comments.filter(c => c.id !== cid))
    } catch (e) {}
  }

  return (
    <div className="post-card card fade-up">
      <div className="post-header">
        <div className="post-avatar">{post.author?.name?.[0]?.toUpperCase()}</div>
        <div className="post-meta">
          <strong>{post.author?.name}</strong>
          <span>{new Date(post.created_at).toLocaleDateString()}</span>
        </div>
        {post.author_id === currentUser?.id && (
          <button className="btn-ghost btn-sm" style={{color:'var(--red)', marginLeft:'auto'}} onClick={() => onDelete(post.id)}>Delete</button>
        )}
      </div>

      <h3 className="post-title">{post.title}</h3>
      <p className="post-content">{post.content}</p>

      <div className="post-actions">
        <button className={`like-btn-sm ${liked ? 'liked' : ''}`} onClick={handleLike}>
          {liked ? '❤️' : '🤍'} {likesCount}
        </button>
        <button className="btn-ghost btn-sm" onClick={toggleExpand}>
          💬 {post.comments_count} {expanded ? 'Hide' : 'Comments'}
        </button>
      </div>

      {expanded && (
        <div className="post-comments">
          {loadingComments && <div className="spinner" style={{width:20,height:20,margin:'12px auto'}} />}
          {comments.map(c => (
            <div key={c.id} className="comment-item">
              <div className="comment-avatar">{c.author?.name?.[0]?.toUpperCase()}</div>
              <div className="comment-body">
                <div className="comment-meta">
                  <strong>{c.author?.name}</strong>
                  <span>{new Date(c.created_at).toLocaleString()}</span>
                </div>
                <p>{c.content}</p>
              </div>
              {c.author_id === currentUser?.id && (
                <button className="btn-ghost btn-sm" style={{color:'var(--red)'}} onClick={() => handleDeleteComment(c.id)}>×</button>
              )}
            </div>
          ))}
          <form onSubmit={handleComment} className="comment-form" style={{marginTop:10}}>
            <input placeholder="Write a comment…" value={commentText} onChange={e => setCommentText(e.target.value)} />
            <button type="submit" className="btn-primary btn-sm">Post</button>
          </form>
        </div>
      )}
    </div>
  )
}

export default function Feed() {
  const { token, user } = useAuth()
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ title: '', content: '' })
  const [posting, setPosting] = useState(false)

  const load = async () => {
    try {
      const data = await api.getFeed(token)
      setPosts(data)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const handlePost = async (e) => {
    e.preventDefault()
    if (!form.title.trim() || !form.content.trim()) return
    setPosting(true)
    try {
      await api.createPost(form, token)
      setForm({ title: '', content: '' })
      setShowForm(false)
      load()
    } catch (e) {
      setError(e.message)
    } finally {
      setPosting(false)
    }
  }

  const handleDelete = async (postId) => {
    try {
      await api.deletePost(postId, token)
      setPosts(posts.filter(p => p.id !== postId))
    } catch (e) {}
  }

  return (
    <div className="feed-page fade-up">
      <div className="feed-header">
        <div>
          <h1>Community Feed</h1>
          <p className="subtitle">Share problems, ideas, and discussions with your peers</p>
        </div>
        <button className="btn-primary" onClick={() => setShowForm(!showForm)}>
          {showForm ? '✕ Cancel' : '✦ New Post'}
        </button>
      </div>

      {showForm && (
        <div className="card new-post-card fade-up">
          <h3 style={{marginBottom:16}}>Share something with the community</h3>
          {error && <div className="error-msg" style={{marginBottom:12}}>{error}</div>}
          <form onSubmit={handlePost} className="post-form">
            <input
              placeholder="Post title — e.g. 'Struggling with async Python, need help!'"
              value={form.title}
              onChange={e => setForm({...form, title: e.target.value})}
              required
            />
            <textarea
              rows={4}
              placeholder="Describe your problem, idea, or topic in detail…"
              value={form.content}
              onChange={e => setForm({...form, content: e.target.value})}
              required
            />
            <div style={{display:'flex', justifyContent:'flex-end'}}>
              <button type="submit" className="btn-primary" disabled={posting}>
                {posting ? 'Posting…' : 'Publish Post'}
              </button>
            </div>
          </form>
        </div>
      )}

      {loading && <div className="spinner" />}

      {!loading && posts.length === 0 && (
        <div className="empty-state">
          <div className="empty-icon">◉</div>
          <p>No posts yet. Start the conversation!</p>
        </div>
      )}

      <div className="feed-list">
        {posts.map(p => (
          <PostCard
            key={p.id}
            post={p}
            token={token}
            currentUser={user}
            onUpdate={load}
            onDelete={handleDelete}
          />
        ))}
      </div>
    </div>
  )
}
