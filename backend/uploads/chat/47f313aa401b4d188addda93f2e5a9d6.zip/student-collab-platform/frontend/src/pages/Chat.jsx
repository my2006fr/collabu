import { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { api } from '../services/api'
import './Chat.css'

export default function Chat() {
  const { id } = useParams()
  const { token, user } = useAuth()
  const navigate = useNavigate()

  const [project, setProject] = useState(null)
  const [messages, setMessages] = useState([])
  const [text, setText] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)
  const bottomRef = useRef(null)
  const pollRef = useRef(null)

  const loadMessages = async () => {
    try {
      const msgs = await api.getMessages(id, token)
      setMessages(msgs)
    } catch (e) {
      setError(e.message)
    }
  }

  useEffect(() => {
    const init = async () => {
      try {
        const p = await api.getProject(id, token)
        setProject(p)
        await loadMessages()
      } catch (e) {
        setError(e.message)
      } finally {
        setLoading(false)
      }
    }
    init()

    // Poll every 4 seconds for new messages
    pollRef.current = setInterval(loadMessages, 4000)
    return () => clearInterval(pollRef.current)
  }, [id])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const send = async (e) => {
    e.preventDefault()
    if (!text.trim()) return
    const content = text.trim()
    setText('')
    try {
      await api.sendMessage(id, { content }, token)
      await loadMessages()
    } catch (e) {
      setError(e.message)
      setText(content)
    }
  }

  const groupByDate = (msgs) => {
    const groups = {}
    msgs.forEach(m => {
      const day = new Date(m.sent_at).toLocaleDateString()
      if (!groups[day]) groups[day] = []
      groups[day].push(m)
    })
    return groups
  }

  if (loading) return <div className="spinner" />
  if (error) return (
    <div style={{padding:32}}>
      <div className="error-msg">{error}</div>
      <button className="btn-ghost" style={{marginTop:12}} onClick={() => navigate(`/projects/${id}`)}>← Back to Project</button>
    </div>
  )

  const grouped = groupByDate(messages)

  return (
    <div className="chat-page fade-up">
      <div className="chat-header">
        <button className="btn-ghost btn-sm" onClick={() => navigate(`/projects/${id}`)}>←</button>
        <div className="chat-project-info">
          <h2>{project?.title}</h2>
          <span className="chat-subtitle">Project Chat · Members only</span>
        </div>
        <div className="online-dot" title="Polling active" />
      </div>

      <div className="chat-body">
        {messages.length === 0 && (
          <div className="chat-empty">
            <div style={{fontSize:'2.5rem'}}>💬</div>
            <p>No messages yet. Say hello to your team!</p>
          </div>
        )}

        {Object.entries(grouped).map(([day, msgs]) => (
          <div key={day}>
            <div className="date-divider"><span>{day}</span></div>
            {msgs.map((m, i) => {
              const isMe = m.sender_id === user?.id
              const showAvatar = i === 0 || msgs[i - 1]?.sender_id !== m.sender_id
              return (
                <div key={m.id} className={`msg-row ${isMe ? 'msg-me' : 'msg-them'}`}>
                  {!isMe && (
                    <div className={`msg-avatar ${showAvatar ? '' : 'msg-avatar-hidden'}`}>
                      {showAvatar ? m.sender?.name?.[0]?.toUpperCase() : ''}
                    </div>
                  )}
                  <div className="msg-bubble-wrap">
                    {!isMe && showAvatar && <span className="msg-sender-name">{m.sender?.name}</span>}
                    <div className={`msg-bubble ${isMe ? 'bubble-me' : 'bubble-them'}`}>
                      {m.content}
                    </div>
                    <span className="msg-time">{new Date(m.sent_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</span>
                  </div>
                </div>
              )
            })}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form className="chat-input-bar" onSubmit={send}>
        <input
          placeholder="Type a message…"
          value={text}
          onChange={e => setText(e.target.value)}
          autoFocus
        />
        <button type="submit" className="send-btn" disabled={!text.trim()}>
          ➤
        </button>
      </form>
    </div>
  )
}
