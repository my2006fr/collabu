import { useState, useEffect } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { api } from '../services/api'
import './ProjectDetail.css'

export default function ProjectDetail() {
  const { id } = useParams()
  const { token, user } = useAuth()
  const navigate = useNavigate()

  const [project, setProject] = useState(null)
  const [comments, setComments] = useState([])
  const [liked, setLiked] = useState(false)
  const [likesCount, setLikesCount] = useState(0)
  const [commentText, setCommentText] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [joinMsg, setJoinMsg] = useState('')

  const load = async () => {
    try {
      const p = await api.getProject(id, token)
      setProject(p)
      setLikesCount(p.likes_count || 0)
      setLiked(p.liked_by_me || false)
      const c = await api.getProjectComments(id, token)
      setComments(c)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [id])

  const handleJoin = async () => {
    try {
      await api.joinProject(id, token)
      setJoinMsg('Request sent! Waiting for owner approval.')
      load()
    } catch (e) {
      setJoinMsg(e.message)
    }
  }

  const handleRespond = async (userId, action) => {
    try {
      await api.respondToJoin(id, { user_id: userId, action }, token)
      load()
    } catch (e) {
      setError(e.message)
    }
  }

  const handleLike = async () => {
    try {
      const res = await api.likeProject(id, token)
      setLiked(res.liked)
      setLikesCount(res.likes_count)
    } catch (e) {}
  }

  const handleComment = async (e) => {
    e.preventDefault()
    if (!commentText.trim()) return
    try {
      await api.commentOnProject(id, { content: commentText }, token)
      setCommentText('')
      load()
    } catch (e) {}
  }

  const handleDeleteComment = async (cid) => {
    try {
      await api.deleteComment(cid, token)
      setComments(comments.filter(c => c.id !== cid))
    } catch (e) {}
  }

  if (loading) return <div className="spinner" />
  if (error) return <div className="error-msg">{error}</div>
  if (!project) return null

  const isOwner = project.owner_id === user?.id
  const isCollaborator = project.collaborators?.some(c => c.user_id === user?.id)
  const hasPending = project.pending_requests?.some(r => r.user_id === user?.id)
  const isMember = isOwner || isCollaborator

  return (
    <div className="project-detail fade-up">
      {/* Header */}
      <div className="detail-header">
        <button className="btn-ghost btn-sm" onClick={() => navigate('/dashboard')}>← Back</button>
        <div className="detail-badges">
          <span className="badge badge-purple">{project.methodology}</span>
          {isOwner && <span className="badge badge-green">Your Project</span>}
          {isCollaborator && <span className="badge badge-yellow">Collaborator</span>}
        </div>
      </div>

      <div className="detail-layout">
        {/* Main */}
        <div className="detail-main">
          <h1 className="detail-title">{project.title}</h1>
          <p className="detail-owner">by <strong>{project.owner?.name}</strong> · {new Date(project.created_at).toLocaleDateString()}</p>
          <p className="detail-desc">{project.description}</p>

          <div className="detail-meta">
            <div className="meta-item">
              <span className="meta-label">Required Skills</span>
              <div className="project-skills">
                {project.required_skills?.split(',').filter(Boolean).map(s => (
                  <span key={s} className="skill-chip">{s.trim()}</span>
                ))}
              </div>
            </div>
            <div className="meta-item">
              <span className="meta-label">GitHub</span>
              <a href={project.github_repo_link} target="_blank" rel="noreferrer" className="github-link">
                🔗 {project.github_repo_link}
              </a>
            </div>
          </div>

          {/* Like + Chat */}
          <div className="action-bar">
            <button
              className={`like-btn ${liked ? 'liked' : ''}`}
              onClick={handleLike}
            >
              {liked ? '❤️' : '🤍'} {likesCount} {likesCount === 1 ? 'like' : 'likes'}
            </button>
            {isMember && (
              <Link to={`/projects/${id}/chat`} className="btn-primary" style={{textDecoration:'none',padding:'9px 18px',borderRadius:'8px',fontFamily:'var(--font-body)',fontWeight:500,fontSize:'0.93rem'}}>
                💬 Project Chat
              </Link>
            )}
            {!isOwner && !isCollaborator && !hasPending && (
              <button className="btn-secondary" onClick={handleJoin}>Request to Join</button>
            )}
            {hasPending && <span className="badge badge-yellow">Request Pending…</span>}
          </div>
          {joinMsg && <div className="success-msg" style={{marginTop:8}}>{joinMsg}</div>}

          {/* Comments */}
          <div className="comments-section">
            <h3>Comments <span className="count-chip">{comments.length}</span></h3>
            <form onSubmit={handleComment} className="comment-form">
              <input
                placeholder="Add a comment…"
                value={commentText}
                onChange={e => setCommentText(e.target.value)}
              />
              <button type="submit" className="btn-primary btn-sm">Post</button>
            </form>
            <div className="comments-list">
              {comments.length === 0 && <p className="no-comments">No comments yet. Be first!</p>}
              {comments.map(c => (
                <div key={c.id} className="comment-item">
                  <div className="comment-avatar">{c.author?.name?.[0]?.toUpperCase()}</div>
                  <div className="comment-body">
                    <div className="comment-meta">
                      <strong>{c.author?.name}</strong>
                      <span>{new Date(c.created_at).toLocaleString()}</span>
                    </div>
                    <p>{c.content}</p>
                  </div>
                  {c.author_id === user?.id && (
                    <button className="btn-ghost btn-sm" style={{color:'var(--red)'}} onClick={() => handleDeleteComment(c.id)}>×</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <aside className="detail-sidebar">
          {/* Collaborators */}
          <div className="card sidebar-card">
            <h4>Collaborators <span className="count-chip">{project.collaborators?.length || 0}</span></h4>
            {project.collaborators?.length === 0 && <p className="muted">No collaborators yet.</p>}
            {project.collaborators?.map(c => (
              <div key={c.id} className="collab-item">
                <div className="comment-avatar">{c.user?.name?.[0]?.toUpperCase()}</div>
                <span>{c.user?.name}</span>
              </div>
            ))}
          </div>

          {/* Pending requests (owner only) */}
          {isOwner && project.pending_requests?.length > 0 && (
            <div className="card sidebar-card">
              <h4>Join Requests <span className="count-chip">{project.pending_requests.length}</span></h4>
              {project.pending_requests.map(r => (
                <div key={r.id} className="request-item">
                  <div className="comment-avatar">{r.user?.name?.[0]?.toUpperCase()}</div>
                  <span className="request-name">{r.user?.name}</span>
                  <div className="request-actions">
                    <button className="btn-sm" style={{background:'var(--green)',color:'#000',borderRadius:6,border:'none',cursor:'pointer',padding:'4px 10px'}} onClick={() => handleRespond(r.user_id, 'accept')}>✓</button>
                    <button className="btn-sm btn-danger" onClick={() => handleRespond(r.user_id, 'reject')}>✕</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </aside>
      </div>
    </div>
  )
}
