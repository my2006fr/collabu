import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { api } from '../services/api'
import './Dashboard.css'

export default function Dashboard() {
  const { token, user } = useAuth()
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')

  useEffect(() => {
    api.getProjects(token)
      .then(setProjects)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }, [token])

  const filtered = projects.filter(p =>
    p.title.toLowerCase().includes(search.toLowerCase()) ||
    p.required_skills?.toLowerCase().includes(search.toLowerCase())
  )

  const levelBadge = (level) => {
    const map = { beginner: 'badge-green', intermediate: 'badge-yellow', advanced: 'badge-red' }
    return map[level] || 'badge-gray'
  }

  return (
    <div className="dashboard fade-up">
      <div className="dashboard-header">
        <div>
          <h1>Projects</h1>
          <p className="subtitle">Discover and join student projects</p>
        </div>
        <Link to="/projects/new" className="btn-primary" style={{textDecoration:'none',padding:'10px 20px',borderRadius:'8px',fontFamily:'var(--font-body)',fontWeight:500}}>
          ✦ New Project
        </Link>
      </div>

      <div className="search-bar">
        <input
          placeholder="Search by title or skills…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {loading && <div className="spinner" />}
      {error && <div className="error-msg">{error}</div>}

      {!loading && filtered.length === 0 && (
        <div className="empty-state">
          <div className="empty-icon">◈</div>
          <p>No projects found. <Link to="/projects/new">Create one!</Link></p>
        </div>
      )}

      <div className="projects-grid">
        {filtered.map(p => (
          <Link to={`/projects/${p.id}`} key={p.id} className="project-card" style={{textDecoration:'none'}}>
            <div className="project-card-top">
              <span className="badge badge-purple">{p.methodology}</span>
              {p.owner_id === user?.id && <span className="badge badge-green">Yours</span>}
            </div>
            <h3 className="project-title">{p.title}</h3>
            <p className="project-desc">{p.description.slice(0, 120)}{p.description.length > 120 ? '…' : ''}</p>
            <div className="project-skills">
              {p.required_skills?.split(',').filter(Boolean).map(s => (
                <span key={s} className="skill-chip">{s.trim()}</span>
              ))}
            </div>
            <div className="project-footer">
              <span className="owner-name">by {p.owner?.name}</span>
              <span className="project-date">{new Date(p.created_at).toLocaleDateString()}</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
