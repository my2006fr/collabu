const BASE = '/api'

function getHeaders(token) {
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  }
}

async function req(method, path, body, token) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: getHeaders(token),
    body: body ? JSON.stringify(body) : undefined,
  })
  const data = await res.json()
  if (!res.ok) throw new Error(data.error || 'Request failed')
  return data
}

export const api = {
  // Auth
  register: (body) => req('POST', '/register', body),
  login: (body) => req('POST', '/login', body),

  // Profile
  getProfile: (token) => req('GET', '/profile', null, token),

  // Projects
  getProjects: (token) => req('GET', '/projects', null, token),
  getProject: (id, token) => req('GET', `/projects/${id}`, null, token),
  createProject: (body, token) => req('POST', '/projects', body, token),
  joinProject: (id, token) => req('POST', `/projects/${id}/join`, {}, token),
  respondToJoin: (id, body, token) => req('POST', `/projects/${id}/accept`, body, token),
  likeProject: (id, token) => req('POST', `/projects/${id}/like`, {}, token),
  getProjectComments: (id, token) => req('GET', `/projects/${id}/comments`, null, token),
  commentOnProject: (id, body, token) => req('POST', `/projects/${id}/comments`, body, token),

  // Messages
  getMessages: (projectId, token) => req('GET', `/projects/${projectId}/messages`, null, token),
  sendMessage: (projectId, body, token) => req('POST', `/projects/${projectId}/messages`, body, token),

  // Feed
  getFeed: (token) => req('GET', '/feed', null, token),
  getPost: (id, token) => req('GET', `/feed/${id}`, null, token),
  createPost: (body, token) => req('POST', '/feed', body, token),
  deletePost: (id, token) => req('DELETE', `/feed/${id}`, null, token),
  likePost: (id, token) => req('POST', `/feed/${id}/like`, {}, token),
  commentOnPost: (id, body, token) => req('POST', `/feed/${id}/comments`, body, token),
  deleteComment: (id, token) => req('DELETE', `/comments/${id}`, null, token),
}
